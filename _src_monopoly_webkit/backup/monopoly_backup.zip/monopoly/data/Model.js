Ext.regModel('UserModel', {
	idProperty : 'id',
    fields: ['id', 'login', 'password']
});